__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/f0a51a6730b4d211.js",
  "static/chunks/turbopack-d7f01fd0badfddaf.js"
])
