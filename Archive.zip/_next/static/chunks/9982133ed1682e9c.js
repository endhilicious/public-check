__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/f0a51a6730b4d211.js",
  "static/chunks/turbopack-b0ca5996ddc7ffb4.js"
])
